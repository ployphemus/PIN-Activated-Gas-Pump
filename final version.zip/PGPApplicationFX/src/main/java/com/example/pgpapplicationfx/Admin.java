package com.example.pgpapplicationfx;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import static com.example.pgpapplicationfx.HelloApplication.data;
/*
 * Updated 4/17/23
 * Class contains methods for admin usertype
 * William Vaughan
 */

public class Admin extends Application{

    protected int pin;               //internal
    protected int index;
    protected String name;
    protected int userType = 0;
    protected String fuel = "00.00";

    public Admin(int index){
        this.index=index;
    }

    //creates all the elements for the menu
    @Override
    public void start(Stage stage) throws Exception {
        VBox main=new VBox();
        main.setPadding(new Insets(10));
        Button button=new Button("Logout");
        button.setOnAction(e -> {
            try {
                mainMenu(stage);
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });
        main.getChildren().addAll(button);

        Text text=new Text();
        VBox addUser=new VBox();
        addUser.setBackground(new Background(new BackgroundFill(Color.GRAY, CornerRadii.EMPTY, Insets.EMPTY)));
        TextField addTextName=new TextField();
        addTextName.setText("Enter Name");
        addTextName.setMaxSize(300, 100);
        TextField addTextPIN=new TextField();
        addTextPIN.setText("Enter PIN");
        addTextPIN.setMaxSize(300, 100);
        TextField addTextUserType=new TextField();
        addTextUserType.setText("Enter User Type(1, 2, 3)");
        addTextUserType.setMaxSize(300, 100);
        Button addButton=new Button("Add User");
        addUser.getChildren().addAll(addTextName, addTextPIN, addTextUserType, addButton);
        addUser.setAlignment(Pos.CENTER);
        addUser.setPadding(new Insets(10));
        addButton.setOnAction(e -> {text.setText(addUser(addTextName.getText(), addTextPIN.getText(), addTextUserType.getText()));});

        VBox removeUser=new VBox();
        removeUser.setBackground(new Background(new BackgroundFill(Color.GRAY, CornerRadii.EMPTY, Insets.EMPTY)));
        TextField removeText=new TextField();
        removeText.setMaxSize(300, 100);
        Button removeButton=new Button("Remove User");
        removeUser.getChildren().addAll(removeText, removeButton);
        removeUser.setAlignment(Pos.CENTER);
        removeUser.setPadding(new Insets(10));
        removeButton.setOnAction(e -> {text.setText(removeUser(removeText.getText()));});

        VBox changeStatus=new VBox();
        changeStatus.setBackground(new Background(new BackgroundFill(Color.GRAY, CornerRadii.EMPTY, Insets.EMPTY)));
        Button changeButton=new Button("Change Pump Status");
        changeStatus.getChildren().addAll(changeButton);
        changeStatus.setAlignment(Pos.CENTER);
        changeStatus.setPadding(new Insets(10));
        changeButton.setOnAction(e -> {text.setText(changeStatus());});

        VBox checkTank=new VBox();
        Button checkButton=new Button("Check Tank");
        checkTank.getChildren().addAll(checkButton);
        checkTank.setAlignment(Pos.CENTER);
        checkTank.setPadding(new Insets(10));
        checkButton.setOnAction(e -> {text.setText(checkTank());});


        Text title=new Text("Admin");
        title.setFont(Font.font(30));
        StackPane root=new StackPane();
        VBox box=new VBox();
        box.setSpacing(10);
        box.setAlignment(Pos.CENTER);
        box.getChildren().addAll(main, title, addUser, removeUser, changeStatus, checkTank, text);
        root.getChildren().addAll(box);
        root.setAlignment(box, Pos.CENTER);
        Scene scene = new Scene(root, 450, 600);
        stage.setTitle("Admin");
        stage.setScene(scene);
        stage.show();
    }

    //displays Javafx menu
    public void mainMenu(Stage stage) throws IOException {
        HelloApplication h=new HelloApplication();
        h.start(stage);
    }
    /**
     * Takes entered PIN, Name, and UserType and saves to CSV file
     */
    public String addUser(String name, String PIN, String userType){
        if(String.valueOf(PIN).length()<4) {
            return "The PIN should be only four digits long";
        }


        if(String.valueOf(name)==null){
            return "Please Enter a name";
        }


        int i=Integer.parseInt(userType);
        if(i!=1){
            return "Please Enter a valid User type\n1. Admin  2. User  3. Truck Driver";
        }




        String[] newRow = {String.valueOf(PIN), name, String.valueOf(userType), "00.00"};
        CsvFile file = new CsvFile("src/main/java/com/example/pgpapplicationfx/pinData.csv");
        file.readData();
        file.addRow(newRow);
        file.writeDataInternal();
        return "User Added: "+name;
    }

    //takes a name from the textbox, and removes the user with the name from the csv file
    public String removeUser(String text) {
        CsvFile file = new CsvFile("src/main/java/com/example/pgpapplicationfx/pinData.csv");
        file.readData();
        file.removeRow(text);
        file.writeDataInternal();
        return "User Removed";
    }

    //reads the csv file to find out how much gas is in the tank
    public String checkTank(){
        return "There are " + data[0][3] + "g in tank.";
    }

    //changes the status of the tank to either online or offline
    public String changeStatus(){
        CsvFile file = new CsvFile("src/main/java/com/example/pgpapplicationfx/pinData.csv");
        if(data[1][3] == "1") {
            data[1][3] = "0";
            file.writeData(data);
            return "The Pump is Now Offline";
        }
        else{
            data[1][3] = "1";
            file.writeData(data);
            return "The Pump is Now Online ";
        }

    }
}
