package com.example.pgpapplicationfx;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;
//!!!first two rows in csv array are tank and pump, do not modify!!!


/*
 * Updated 4/17/23
 *
 * Class contains main methods and springboot initalizer.
 * William Vaughan
 * Greyson Williams
 */
public class HelloApplication extends Application {

    static String[][] data;
    static String verNum = "0.1";


    @Override
    public void start(Stage stage) throws IOException {
        mainMenu(stage);


    }

    public Scene mainMenu(Stage stage) {

        String pin;
        int index;

        //initialize csvFile and get csv file contents
        CsvFile file = new CsvFile("src/main/java/com/example/pgpapplicationfx/pinData.csv");

        //store csv to class array/reload array from modified csv file
        file.readData();
        //store csv file to 2d array for public access
        data = file.getData();


        //get pin and match with db to figure out role
        TextField input = new TextField("Admin, User, or Truck Driver");
        input.setMinSize(300, 40);
        input.setMaxSize(300, 40);
        input.setFont(Font.font(20));
        input.setOnAction(e -> {
            try {
                checkInput(input.getText(), stage);
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        });
        Button button = new Button("Enter");
        button.setMinSize(100, 80);
        button.setMaxSize(100, 80);
        button.setFont(Font.font(20));
        button.setOnAction(e -> {
            try {
                checkInput(input.getText(), stage);
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        });
        Text title = new Text("PIN Activated Gas Pump");
        title.setFont(Font.font(30));
        StackPane root = new StackPane();
        root.setPrefSize(450, 600);
        VBox box = new VBox();
        box.setSpacing(10);
        box.setAlignment(Pos.CENTER);
        box.getChildren().addAll(input, button);
        root.getChildren().addAll(title, box);
        root.setAlignment(title, Pos.TOP_CENTER);
        root.setAlignment(box, Pos.CENTER);
        root.setPadding(new Insets(40));
        Scene scene = new Scene(root);
        stage.setTitle("Main Menu");
        stage.setScene(scene);
        stage.show();
        return scene;
    }

    public void checkInput(String s, Stage stage) throws Exception {
        int index;
        index = checkPin(s);

        if (index != 0) {
            if (Objects.equals(data[index][2], "1")) {
                new Admin(index).start(stage);
            } else if (Objects.equals(data[index][2], "2")) {
                new User(index).start(stage);
            } else if (Objects.equals(data[index][2], "3")) {
                new truckDriver(index).start(stage);
            } else {
                error(stage);
            }
        }
    }

    public static int checkPin(String pin) {
        //skips pump and tank entries
        for (int i = 2; i < data.length; i++) {
            if (Objects.equals(data[i][0], pin)) {
                System.out.println("PIN authenticated");
                return i;
            }
        }
        System.out.println("PIN !!NOT!! authenticated!");
        return 0;
    }

    public Scene error(Stage stage) {
        TextField input = new TextField("Admin, User, or Truck Driver");
        input.setOnAction(e -> {
            try {
                checkInput(input.getText(), stage);
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        });
        input.setMinSize(300, 40);
        input.setMaxSize(300, 40);
        input.setFont(Font.font(20));
        ;
        Button button = new Button("Enter");
        button.setMinSize(100, 80);
        button.setMaxSize(100, 80);
        button.setFont(Font.font(20));
        button.setOnAction(e -> {
            try {
                checkInput(input.getText(), stage);
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        });
        Text title = new Text("PIN Activated Gas Pump");
        title.setFont(Font.font(30));
        Text error = new Text("Error, enter a valid option. ");
        StackPane root = new StackPane();
        root.setPrefSize(450, 600);
        VBox box = new VBox();
        box.setSpacing(10);
        box.setAlignment(Pos.CENTER);
        box.getChildren().addAll(input, button, error);
        root.getChildren().addAll(title, box);
        root.setAlignment(title, Pos.TOP_CENTER);
        root.setAlignment(box, Pos.CENTER);
        root.setPadding(new Insets(40));
        Scene scene = new Scene(root);
        stage.setTitle("Main Menu");
        stage.setScene(scene);
        stage.show();
        return scene;
    }













        public static void main(String[] args) {
        launch();
    }
}
