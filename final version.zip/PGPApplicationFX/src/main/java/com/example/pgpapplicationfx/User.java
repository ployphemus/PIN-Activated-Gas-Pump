package com.example.pgpapplicationfx;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;
import static com.example.pgpapplicationfx.HelloApplication.data;

public class User extends Application{

    protected int index;

    public User(int index){
        this.index=index;
    }

    //creates elements for menu
    @Override
    public void start(Stage stage) throws Exception {
        VBox main=new VBox();
        main.setPadding(new Insets(10));
        Button button=new Button("Logout");
        button.setOnAction(e-> {
            try {
                mainMenu(stage);
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });
        main.getChildren().addAll(button);

        Text text=new Text();
        VBox pumpGas=new VBox();
        pumpGas.setBackground(new Background(new BackgroundFill(Color.GRAY, CornerRadii.EMPTY, Insets.EMPTY)));
        TextField pumpText=new TextField();
        Button pumpButton=new Button("Pump Gas");
        pumpGas.getChildren().addAll(pumpText, pumpButton);
        pumpGas.setAlignment(Pos.CENTER);
        pumpGas.setPadding(new Insets(10));
        pumpButton.setOnAction(e -> {text.setText(pumpGas(pumpText.getText()));});

        VBox checkTotal=new VBox();
        checkTotal.setMaxHeight(100);
        checkTotal.setAlignment(Pos.CENTER);
        Button checkButton=new Button("Check Total Used");
        checkTotal.getChildren().addAll(checkButton);
        checkButton.setOnAction(e -> {text.setText(checkTotal());});

        VBox checkTank=new VBox();
        checkTank.setMaxHeight(100);
        checkTank.setAlignment(Pos.CENTER);
        Button checkTankButton=new Button("Check Tank Level");
        checkTank.getChildren().addAll(checkTankButton);
        checkTankButton.setOnAction(e -> {text.setText(checkTank());});

        Text title=new Text("User");
        title.setFont(Font.font(30));
        VBox box=new VBox();
        box.setSpacing(10);
        box.getChildren().addAll(main, title, pumpGas, checkTotal, checkTank, text);
        box.setAlignment(Pos.CENTER);
        StackPane root=new StackPane();
        root.getChildren().addAll(box);
        root.setAlignment(box, Pos.CENTER);
        Scene scene = new Scene(root, 450, 600);
        stage.setTitle("User");
        stage.setScene(scene);
        stage.show();
    }

    //displays javafx menu
    public void mainMenu(Stage stage) throws IOException {
        HelloApplication h=new HelloApplication();
        h.start(stage);
    }

    //takes and input and subtracts it from the tank's total in the csv file
    public String pumpGas(String text){
        CsvFile file = new CsvFile("src/main/java/com/example/pgpapplicationfx/pinData.csv");

        if(Objects.equals(data[1][3], "0")){
            return "Pump is disabled, please contact an administrator.";
        }
        else if(Double.parseDouble(data[0][3]) < 100){
            data[1][3] = "0";
            file.writeData(data);
            return "Level in tank is too low,\npump has been disabled.\nPlease contact an administrator.";

        }
        else {
            int amount=Integer.parseInt(text);
            data[index][3] = String.valueOf(Double.parseDouble(data[index][3]) + amount);
            data[0][3] = String.valueOf(Double.parseDouble(data[0][3]) - amount);
            file.writeData(data);
            return "Dispensed "+amount+" Gallons, Thank You";
        }

    }


    //displays the amount of gas the user has used
    public String checkTotal(){
        return "You have used "+ data[index][3] + " gallons of fuel.";
    }

    //displays the amount of gas that is in the tank
    public String checkTank(){
        return "There are " + data[0][3] + "g in tank.";
    }
}
