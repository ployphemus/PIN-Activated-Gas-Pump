package com.example.pgpapplicationfx;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;

import static com.example.pgpapplicationfx.GasApi.getGasPrice;
import static com.example.pgpapplicationfx.HelloApplication.data;

public class truckDriver extends Application {

    protected int index;

    public truckDriver(int index){
        this.index=index;
    }

    //creates all of the elements needed for the menu
    @Override
    public void start(Stage stage) throws Exception {
        VBox main=new VBox();
        main.setPadding(new Insets(10));
        Button button=new Button("Logout");
        button.setOnAction(e -> {
            try {
                mainMenu(stage);
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });
        main.getChildren().addAll(button);

        Text text=new Text();
        VBox addFuel=new VBox();
        addFuel.setBackground(new Background(new BackgroundFill(Color.GRAY, CornerRadii.EMPTY, Insets.EMPTY)));
        TextField addText=new TextField();
        addText.setMaxSize(300, 100);
        Button addButton=new Button("Add Fuel");
        addFuel.getChildren().addAll(addText, addButton);
        addFuel.setAlignment(Pos.CENTER);
        addFuel.setPadding(new Insets(10));
        addButton.setOnAction(e -> {
            try {
                text.setText(addFuel(addText.getText()));
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });

        VBox checkTotal=new VBox();
        checkTotal.setMinSize(300, 100);
        Button checkButton=new Button("Check Total Added");
        checkTotal.getChildren().addAll(checkButton);
        checkTotal.setAlignment(Pos.CENTER);
        checkTotal.setPadding(new Insets(10));
        checkButton.setOnAction(e -> {text.setText(checkTotal());});

        VBox changeStatus=new VBox();
        changeStatus.setBackground(new Background(new BackgroundFill(Color.GRAY, CornerRadii.EMPTY, Insets.EMPTY)));
        Button changeButton=new Button("Change Pump Status");
        changeStatus.getChildren().addAll(changeButton);
        changeStatus.setAlignment(Pos.CENTER);
        changeStatus.setPadding(new Insets(10));
        changeButton.setOnAction(e -> {text.setText(changeStatus());});

        Text title=new Text("Truck Driver");
        title.setFont(Font.font(30));
        StackPane root=new StackPane();
        VBox box=new VBox();
        box.setSpacing(10);
        box.setAlignment(Pos.CENTER);
        box.getChildren().addAll(main, title, addFuel, changeStatus, checkTotal, text);
        root.getChildren().addAll(box);
        root.setAlignment(box, Pos.CENTER);
        Scene scene = new Scene(root, 450, 600);
        stage.setTitle("Truck Driver");
        stage.setScene(scene);
        stage.show();
    }

    //displays a javafx menu for fueltruck drivers
    public void mainMenu(Stage stage) throws IOException {
        HelloApplication h=new HelloApplication();
        h.start(stage);
    }

    //takes an input from user of how much fuel to add, then will write to file how much gas is inputted
    public String addFuel(String text) throws IOException {
        Boolean tooBig = true;
        double gasP = getGasPrice(35.9132, -79.0558);
        double amountAval = 50000 - Double.parseDouble(data[0][3]);
        int gAmount = Integer.parseInt(text);
        while (tooBig) {
            if (gAmount + Double.parseDouble(data[0][3]) > 50000) {
                return "!Added amount will overflow tank!\nPlease enter an amount smaller than "
                        + amountAval + "g";
            } else {
                CsvFile file = new CsvFile("src/main/java/com/example/pgpapplicationfx/pinData.csv");
                data[index][3] = String.valueOf(Double.parseDouble(data[index][3]) + 55.33);
                file.writeData(data);
                tooBig = false;
                return "Estimated total cost of fuel is: $" + gAmount * gasP;
            }
        }
        return "Error";
    }

    //checks how much gas the driver has inputted to the tank
    public String checkTotal(){
            return "Driver has delivered " + Double.parseDouble(data[index][3]) + "G of fuel";
    }

    //changes the status of the tank to either online or offline
    public String changeStatus(){
        CsvFile file = new CsvFile("src/main/java/com/example/pgpapplicationfx/pinData.csv");
        if(data[1][3] == "1") {
            data[1][3] = "0";
            file.writeData(data);
            return "The Pump is Now Offline";
        }
        else{
            data[1][3] = "1";
            file.writeData(data);
            return "The Pump is Now Online ";
        }    }
}
